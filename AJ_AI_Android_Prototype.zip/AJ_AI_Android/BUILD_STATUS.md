# AJ AI Android build status

The project is configured for an EAS cloud APK build (`eas.json`, `preview` profile).

An APK has **not** been built in this environment. A signed Android binary requires an authenticated Expo/EAS account and a cloud build submission. This workspace has no Android SDK/Gradle build environment and no Expo account credentials, so it cannot submit or retrieve the APK on the user's behalf.

Once the project is submitted to EAS from an authenticated Expo account, run:

```bash
eas build --platform android --profile preview
```

EAS will provide a direct APK download URL when the build succeeds.
