# AJ AI — Android prototype

A dark navy/black bilingual AI assistant prototype built with Expo + React Native.

## Included
- Home screen with glowing AJ branding
- Chat screen with demo responses in Hindi and English
- Voice input using Android speech recognition (requires device speech services and microphone permission)
- Spoken responses using Expo Speech
- Local chat history and settings persistence
- Language selection and spoken-response toggle

## Run on Android
1. Install Node.js (LTS) and Android Studio, or use an Android phone with Expo Go.
2. In this folder run:
   ```bash
   npm install
   npx expo start
   ```
3. Scan the QR code with Expo Go. For native speech-recognition support, create a development build:
   ```bash
   npx expo run:android
   ```
   The speech-recognition config plugin requires a native rebuild; it will not work in the standard Expo Go client.

## Build an installable APK
Install EAS CLI and sign in:
```bash
npm install -g eas-cli
eas build:configure
eas build --platform android --profile preview
```
Create an `eas.json` with:
```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" }
    }
  }
}
```
Then run `eas build --platform android --profile preview`. This creates an installable APK via Expo's build service.

## Important: demo AI
The chat currently uses local sample responses so the UI works without credentials. To connect a real AI model, add a backend endpoint and call it from `send()`. Keep provider API keys on the server; do not bundle secrets in the Android app.

## Notes
- The app stores settings, current conversation, and saved history on-device using AsyncStorage.
- Speech recognition availability depends on Android speech services and device language packs.
- For production, add privacy disclosures, error handling, rate limits, and a secure backend.
