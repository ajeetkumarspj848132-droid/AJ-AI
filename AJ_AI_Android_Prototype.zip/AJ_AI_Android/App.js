import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, StatusBar, Switch, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';

const C = { bg:'#050A16', panel:'#0D1830', panel2:'#122342', blue:'#168BFF', cyan:'#55C8FF', text:'#F3F7FF', muted:'#91A5C5', line:'#203454', green:'#38D99A' };
const starter = [{id:'welcome',role:'assistant',text:'Hello! I’m AJ AI. Ask me anything in English or Hindi.\\n\\nनमस्ते! मैं AJ AI हूँ। आप मुझसे हिंदी या English में कुछ भी पूछ सकते हैं।',time:Date.now()}];

function answerFor(input, language) {
  const q=input.toLowerCase();
  if (/^(hi|hello|hey|नमस्ते|हेलो)/i.test(input)) return language==='hi'?'नमस्ते! मैं AJ AI हूँ। आज मैं आपकी किस तरह मदद कर सकता हूँ?':'Hello! I’m AJ AI. What can I help you with today?';
  if (q.includes('time') || q.includes('समय')) return language==='hi'?'मैं अभी आपके डिवाइस की घड़ी नहीं पढ़ सकता, लेकिन आप अपने फ़ोन पर समय देख सकते हैं।':'I can help with many questions, but this demo does not access your device clock.';
  if (q.includes('your name') || q.includes('तुम्हारा नाम')) return language==='hi'?'मेरा नाम AJ AI है — आपका bilingual AI assistant!':'I’m AJ AI, your bilingual AI assistant!';
  if (q.includes('joke') || q.includes('चुटकुला')) return language==='hi'?'टीचर: होमवर्क कहाँ है? छात्र: सर, होमवर्क तो किया था, लेकिन कॉपी घर पर आराम कर रही है!':'Why did the computer go to the doctor? Because it caught a virus!';
  if (q.includes('translate') || q.includes('अनुवाद')) return language==='hi'?'जिस वाक्य का अनुवाद चाहिए, उसे भेजें।':'Send me the sentence you want translated, and tell me the target language.';
  return language==='hi'?'यह AJ AI का डेमो उत्तर है। असली AI उत्तर पाने के लिए ऐप को सुरक्षित backend API से जोड़ना होगा। आप अपना सवाल थोड़ा और विस्तार से पूछ सकते हैं।':'This is a demo response from AJ AI. To get real AI-generated answers, connect the app to a secure backend API. You can ask me another question or try the voice feature.';
}

export default function App() {
  const [tab,setTab]=useState('Home');
  const [language,setLanguage]=useState('en');
  const [voice,setVoice]=useState(true);
  const [listening,setListening]=useState(false);
  const [input,setInput]=useState('');
  const [chats,setChats]=useState(starter);
  const [history,setHistory]=useState([]);
  const [busy,setBusy]=useState(false);

  useEffect(()=>{(async()=>{try{
    const saved=await AsyncStorage.getItem('aj-settings'); if(saved){const s=JSON.parse(saved);setLanguage(s.language||'en');setVoice(s.voice!==false);}
    const h=await AsyncStorage.getItem('aj-history'); if(h)setHistory(JSON.parse(h));
    const c=await AsyncStorage.getItem('aj-current'); if(c)setChats(JSON.parse(c));
  }catch(e){}})();},[]);
  useEffect(()=>{AsyncStorage.setItem('aj-settings',JSON.stringify({language,voice})).catch(()=>{});},[language,voice]);
  useEffect(()=>{AsyncStorage.setItem('aj-current',JSON.stringify(chats)).catch(()=>{});},[chats]);

  useSpeechRecognitionEvent('result', event => {
    const transcript=event.results?.[0]?.transcript;
    if(transcript) setInput(transcript);
  });
  useSpeechRecognitionEvent('end',()=>setListening(false));
  useSpeechRecognitionEvent('error',event=>{setListening(false);Alert.alert('Voice input',event.message||'Speech recognition is unavailable.');});

  const speak=(text)=>{if(voice) Speech.speak(text,{language:language==='hi'?'hi-IN':'en-IN',rate:0.95});};
  const send=()=>{
    const value=input.trim(); if(!value||busy)return;
    const user={id:String(Date.now()),role:'user',text:value,time:Date.now()};
    setChats(old=>[...old,user]);setInput('');setBusy(true);
    setTimeout(()=>{
      const reply={id:String(Date.now()+1),role:'assistant',text:answerFor(value,language),time:Date.now()};
      setChats(old=>[...old,reply]);setBusy(false);speak(reply.text);
    },650);
  };
  const startVoice=async()=>{
    try{
      if(listening){ExpoSpeechRecognitionModule.stop();setListening(false);return;}
      const permission=await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if(!permission.granted){Alert.alert('Microphone permission','Please allow microphone access in Android settings.');return;}
      setListening(true);
      ExpoSpeechRecognitionModule.start({lang:language==='hi'?'hi-IN':'en-IN',interimResults:true,continuous:false});
    }catch(e){setListening(false);Alert.alert('Voice input unavailable','Try installing the app on an Android device with speech recognition services enabled.');}
  };
  const saveConversation=async()=>{
    if(chats.length<=1){Alert.alert('Nothing to save','Start a conversation first.');return;}
    const item={id:String(Date.now()),title:chats.find(x=>x.role==='user')?.text?.slice(0,38)||'New chat',date:new Date().toLocaleString(),messages:chats};
    const next=[item,...history];setHistory(next);await AsyncStorage.setItem('aj-history',JSON.stringify(next));
    Alert.alert('Saved','Your conversation was added to chat history.');
  };
  const newChat=()=>{setChats(starter);setTab('Chat');};
  const Header=()=> <View style={s.header}>
    <View style={s.brand}><View style={s.logo}><Text style={s.logoText}>AJ</Text></View><View><Text style={s.brandName}>AJ AI</Text><Text style={s.brandSub}>YOUR PERSONAL AI</Text></View></View>
    <View style={s.online}><View style={s.dot}/><Text style={s.onlineText}>ONLINE</Text></View>
  </View>;
  const Nav=()=> <View style={s.nav}>{[['Home','home-variant'],['Chat','chat-processing-outline'],['History','history'],['Settings','cog-outline']].map(([name,icon])=><TouchableOpacity key={name} style={s.navItem} onPress={()=>setTab(name)}><MaterialCommunityIcons name={icon} size={22} color={tab===name?C.cyan:C.muted}/><Text style={[s.navText,tab===name&&{color:C.cyan}]}>{name}</Text></TouchableOpacity>)}</View>;
  const Home=()=> <ScrollView contentContainerStyle={s.homeBody}>
    <View style={s.hero}>
      <View style={s.heroGlow}><Text style={s.heroLogo}>AJ</Text></View>
      <Text style={s.title}>Hello! I’m AJ AI</Text>
      <Text style={s.subTitle}>Your intelligent companion, always ready.</Text>
      <Text style={s.hindi}>नमस्ते! आपका AI सहायक तैयार है।</Text>
    </View>
    <View style={s.card}><Text style={s.cardTitle}>What can I help you with?</Text><Text style={s.muted}>Choose a quick prompt to get started.</Text>
      <View style={s.chips}>{['Ask a question','Tell me a joke','Translate Hindi','Help me learn'].map((x,i)=><TouchableOpacity key={x} style={s.chip} onPress={()=>{setInput(x);setTab('Chat');}}><Text style={s.chipText}>{x}</Text></TouchableOpacity>)}</View>
    </View>
    <TouchableOpacity style={s.voiceCard} onPress={()=>setTab('Chat')}><View style={s.voiceIcon}><MaterialCommunityIcons name="microphone" size={28} color="white"/></View><View><Text style={s.cardTitle}>Talk to AJ</Text><Text style={s.muted}>Start a voice conversation</Text></View><MaterialCommunityIcons name="chevron-right" color={C.cyan} size={25}/></TouchableOpacity>
    <View style={s.featureRow}><View style={s.feature}><MaterialCommunityIcons name="translate" color={C.cyan} size={23}/><Text style={s.featureTitle}>Bilingual</Text><Text style={s.muted}>Hindi + English</Text></View><View style={s.feature}><MaterialCommunityIcons name="volume-high" color={C.cyan} size={23}/><Text style={s.featureTitle}>Voice replies</Text><Text style={s.muted}>Speak answers</Text></View></View>
  </ScrollView>;
  const Chat=()=> <View style={s.chatWrap}>
    <View style={s.chatTop}><View><Text style={s.pageTitle}>AI Assistant</Text><Text style={s.muted}>Chat in Hindi or English</Text></View><TouchableOpacity onPress={saveConversation} style={s.iconButton}><MaterialCommunityIcons name="content-save-outline" size={21} color={C.cyan}/></TouchableOpacity></View>
    <ScrollView style={s.messages} contentContainerStyle={{paddingBottom:18}}>{chats.map(m=><View key={m.id} style={[s.message,m.role==='user'?s.userMessage:s.aiMessage]}><Text style={s.messageRole}>{m.role==='user'?'YOU':'AJ AI'}</Text><Text style={s.messageText}>{m.text}</Text>{m.role==='assistant'&&<TouchableOpacity onPress={()=>speak(m.text)} style={s.speakBtn}><MaterialCommunityIcons name="volume-high" size={17} color={C.cyan}/><Text style={s.speakText}>Listen</Text></TouchableOpacity>}</View>)}{busy&&<Text style={s.typing}>AJ AI is thinking...</Text>}</ScrollView>
    <View style={s.composer}><TouchableOpacity onPress={startVoice} style={[s.micButton,listening&&s.micActive]}><MaterialCommunityIcons name={listening?'stop':'microphone'} size={23} color="white"/></TouchableOpacity><TextInput value={input} onChangeText={setInput} placeholder={language==='hi'?'अपना संदेश लिखें...':'Message AJ AI...'} placeholderTextColor="#7387A8" style={s.input} multiline/><TouchableOpacity onPress={send} style={s.sendButton}><MaterialCommunityIcons name="send" size={20} color="white"/></TouchableOpacity></View>
    <Text style={s.hint}>{listening?'Listening… speak now':'Tap the mic to speak • Demo AI responses'}</Text>
  </View>;
  const History=()=> <ScrollView contentContainerStyle={s.pageBody}><Text style={s.pageTitle}>Chat History</Text><Text style={s.muted}>Your saved conversations live here.</Text>{history.length===0?<View style={s.empty}><MaterialCommunityIcons name="history" size={42} color={C.muted}/><Text style={s.cardTitle}>No saved chats yet</Text><Text style={s.muted}>Save a conversation from the Chat screen.</Text></View>:history.map(item=><TouchableOpacity key={item.id} style={s.historyItem} onPress={()=>{setChats(item.messages);setTab('Chat');}}><MaterialCommunityIcons name="message-text-outline" color={C.cyan} size={23}/><View style={{flex:1}}><Text style={s.historyTitle}>{item.title}</Text><Text style={s.muted}>{item.date}</Text></View><MaterialCommunityIcons name="chevron-right" color={C.muted} size={22}/></TouchableOpacity>)}</ScrollView>;
  const Settings=()=> <ScrollView contentContainerStyle={s.pageBody}><Text style={s.pageTitle}>Settings</Text><Text style={s.muted}>Make AJ AI work your way.</Text>
    <View style={s.settingCard}><Text style={s.settingHeading}>LANGUAGE</Text><TouchableOpacity style={s.settingRow} onPress={()=>setLanguage('en')}><View><Text style={s.settingTitle}>English</Text><Text style={s.muted}>English (India)</Text></View><MaterialCommunityIcons name={language==='en'?'radiobox-marked':'radiobox-blank'} color={C.cyan} size={22}/></TouchableOpacity><View style={s.separator}/><TouchableOpacity style={s.settingRow} onPress={()=>setLanguage('hi')}><View><Text style={s.settingTitle}>हिन्दी</Text><Text style={s.muted}>Hindi (India)</Text></View><MaterialCommunityIcons name={language==='hi'?'radiobox-marked':'radiobox-blank'} color={C.cyan} size={22}/></TouchableOpacity></View>
    <View style={s.settingCard}><Text style={s.settingHeading}>VOICE & AUDIO</Text><View style={s.settingRow}><View><Text style={s.settingTitle}>Spoken responses</Text><Text style={s.muted}>Read AJ AI replies aloud</Text></View><Switch value={voice} onValueChange={setVoice} trackColor={{false:'#33445F',true:'#126BD1'}} thumbColor="white"/></View></View>
    <View style={s.settingCard}><Text style={s.settingHeading}>ABOUT</Text><View style={s.settingRow}><Text style={s.settingTitle}>AJ AI Prototype</Text><Text style={s.muted}>Version 1.0.0</Text></View><Text style={s.aboutText}>This prototype uses local demo responses. Connect a secure server-side AI API to enable live AI answers. Never place private API keys inside the mobile app.</Text></View>
  </ScrollView>;
  return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor={C.bg}/><Header/><View style={s.content}>{tab==='Home'?<Home/>:tab==='Chat'?<Chat/>:tab==='History'?<History/>:<Settings/>}</View><Nav/></SafeAreaView>;
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:C.bg},header:{height:72,paddingHorizontal:20,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderColor:C.line},
 brand:{flexDirection:'row',alignItems:'center',gap:11},logo:{width:43,height:43,borderRadius:14,backgroundColor:'#102E59',borderWidth:1,borderColor:'#268EFF',alignItems:'center',justifyContent:'center',shadowColor:C.blue,shadowOpacity:.55,shadowRadius:12,elevation:7},logoText:{fontSize:20,fontWeight:'900',color:C.cyan,letterSpacing:-1},brandName:{fontSize:19,fontWeight:'800',color:C.text,letterSpacing:.6},brandSub:{fontSize:9,color:C.muted,letterSpacing:1.5,marginTop:2},online:{flexDirection:'row',alignItems:'center',gap:7,backgroundColor:'#102B2B',paddingHorizontal:11,paddingVertical:7,borderRadius:20},dot:{width:7,height:7,borderRadius:4,backgroundColor:C.green},onlineText:{fontSize:10,color:C.green,fontWeight:'800',letterSpacing:1},
 content:{flex:1},homeBody:{padding:20,paddingBottom:30},hero:{alignItems:'center',paddingTop:24,paddingBottom:26},heroGlow:{width:128,height:128,borderRadius:64,backgroundColor:'#102D59',borderWidth:2,borderColor:'#258CFF',alignItems:'center',justifyContent:'center',marginBottom:22,shadowColor:'#168BFF',shadowOpacity:.75,shadowRadius:25,elevation:14},heroLogo:{fontSize:48,fontWeight:'900',color:C.cyan,letterSpacing:-4},title:{fontSize:25,fontWeight:'800',color:C.text},subTitle:{fontSize:13,color:C.muted,marginTop:8},hindi:{fontSize:13,color:C.cyan,marginTop:9},
 card:{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:20,padding:17,marginBottom:14},cardTitle:{fontSize:16,fontWeight:'700',color:C.text},muted:{fontSize:12,color:C.muted,marginTop:5},chips:{flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:16},chip:{backgroundColor:C.panel2,borderWidth:1,borderColor:'#28466E',borderRadius:20,paddingVertical:9,paddingHorizontal:12},chipText:{fontSize:11,color:'#C8E3FF',fontWeight:'600'},
 voiceCard:{backgroundColor:'#0E2342',borderWidth:1,borderColor:'#20538A',borderRadius:18,padding:15,flexDirection:'row',alignItems:'center',gap:13,marginBottom:14},voiceIcon:{width:48,height:48,borderRadius:16,backgroundColor:'#126BD1',alignItems:'center',justifyContent:'center'},featureRow:{flexDirection:'row',gap:12},feature:{flex:1,backgroundColor:C.panel,borderRadius:16,borderWidth:1,borderColor:C.line,padding:15},featureTitle:{color:C.text,fontWeight:'700',fontSize:13,marginTop:8},
 nav:{height:68,borderTopWidth:1,borderColor:C.line,backgroundColor:'#081225',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{alignItems:'center',gap:3,flex:1},navText:{fontSize:10,color:C.muted,fontWeight:'600'},
 chatWrap:{flex:1,paddingHorizontal:15,paddingTop:12,paddingBottom:6},chatTop:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingBottom:12},pageTitle:{fontSize:23,fontWeight:'800',color:C.text},iconButton:{width:42,height:42,borderRadius:14,backgroundColor:C.panel2,alignItems:'center',justifyContent:'center'},messages:{flex:1},message:{maxWidth:'88%',padding:13,borderRadius:17,marginVertical:6},aiMessage:{alignSelf:'flex-start',backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderTopLeftRadius:5},userMessage:{alignSelf:'flex-end',backgroundColor:'#104B89',borderTopRightRadius:5},messageRole:{fontSize:9,fontWeight:'900',color:C.cyan,letterSpacing:1,marginBottom:6},messageText:{fontSize:14,color:C.text,lineHeight:21},speakBtn:{flexDirection:'row',alignItems:'center',gap:5,marginTop:10},speakText:{fontSize:11,color:C.cyan},typing:{color:C.muted,fontSize:12,padding:10},composer:{flexDirection:'row',alignItems:'center',gap:8,backgroundColor:C.panel,borderWidth:1,borderColor:'#28466E',borderRadius:18,padding:7},micButton:{width:43,height:43,borderRadius:14,backgroundColor:'#126BD1',alignItems:'center',justifyContent:'center'},micActive:{backgroundColor:'#C0395B'},input:{flex:1,color:C.text,fontSize:14,maxHeight:90,paddingHorizontal:5},sendButton:{width:43,height:43,borderRadius:14,backgroundColor:C.blue,alignItems:'center',justifyContent:'center'},hint:{textAlign:'center',fontSize:10,color:C.muted,paddingVertical:7},
 pageBody:{padding:20,paddingBottom:30},empty:{alignItems:'center',padding:35,marginTop:25,backgroundColor:C.panel,borderRadius:18,gap:8},historyItem:{flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:15,padding:15,marginTop:12},historyTitle:{fontSize:14,color:C.text,fontWeight:'700'},settingCard:{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:17,padding:16,marginTop:16},settingHeading:{fontSize:10,color:C.cyan,fontWeight:'900',letterSpacing:1.5,marginBottom:8},settingRow:{minHeight:55,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},settingTitle:{fontSize:14,color:C.text,fontWeight:'600'},separator:{height:1,backgroundColor:C.line},aboutText:{fontSize:12,color:C.muted,lineHeight:19,marginTop:8}
});
